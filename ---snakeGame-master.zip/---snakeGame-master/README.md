# 微信小程序-贪吃蛇snakeGame
### 微信小程序-小游戏项目(贪吃蛇)
微信小程序-贪吃蛇   功能: 得分计算/蛇长计算/游戏加速/蛇加长 (吃到食物, 蛇加长, 移动速度加快, 游戏结束计算得分/蛇长)

### 效果图集
![](/demo.gif) 
### [简书地址](http://www.jianshu.com/p/df01c387fd66)  http://www.jianshu.com/p/df01c387fd66
 
